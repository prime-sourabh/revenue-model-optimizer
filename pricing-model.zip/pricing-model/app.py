# app.py

from fastapi import FastAPI, Request
from model_predictor import ProductInput, predict_strategy
from fastapi.responses import JSONResponse
from gemini_classifier import extract_categories_from_products, get_pricing_reason
from pydantic import BaseModel
from typing import List, Dict, Any


app = FastAPI()

# ML-based prediction route
@app.post("/predict-strategy")
def predict_pricing_strategy(data: ProductInput):
    result = predict_strategy(data)
    if not isinstance(result, dict):
        return {"suggested_pricing_model": "unknown", "reason": "Prediction failed."}
    model_name = result.get("suggested_pricing_model", "unknown")
    # Convert ProductInput to dict for Gemini
    product_dict = data.dict() if hasattr(data, 'dict') else dict(data)
    if model_name != "unknown":
        reason = get_pricing_reason(product_dict, model_name)
        result["reason"] = reason
    return result

# Gemini-powered category checker
class ProductData(BaseModel):
    data: Dict[str, Any]

@app.post("/classify-existing-categories")
async def classify_existing(body: ProductData):
    products = body.data.get("products", [])

    if not products:
        return JSONResponse(
            status_code=400,
            content={"error": "No products found in the request"}
        )

    matched_categories = extract_categories_from_products(products)
    return {
        "categories_in_training_data": matched_categories
    }
