# gemini_classifier.py
import google.generativeai as genai
from dotenv import load_dotenv
import os

load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

TRAINED_CATEGORIES = [
    "fashion", "fitness", "electronics", "furniture", "food"
]

model = genai.GenerativeModel("models/gemini-1.5-flash")

def classify_category(product):
    prompt = f"""
You are a product categorization expert for an e-commerce platform.

Your task is to assign the most appropriate category from the following trained categories:
{', '.join(TRAINED_CATEGORIES)}.

Please analyze the product's title, description, and tags to make your decision.

Return only **one** category name that best matches the product from the list. Do not include explanations.

Product Details:
- Title: {product.get('title', '').strip()}
- Description (HTML may be present): {product.get('body_html', '').strip()}
- Tags: {product.get('tags', '').strip()}

Category:
"""

    response = model.generate_content(prompt)
    return response.text.strip().lower()

def extract_categories_from_products(products: list) -> list:
    matched_categories = []
    for product in products:
        category = classify_category(product)
        if category in TRAINED_CATEGORIES and category not in matched_categories:
            matched_categories.append(category)
    return matched_categories

def get_pricing_reason(product: dict, model_name: str) -> str:
    """
    Generate a simple, easy-to-understand explanation for why the given pricing model is suitable for the product.
    Returns a single concise reason (not bullet points), around 30 words, in plain language anyone can understand.
    """
    prompt = f"""
You are a pricing strategy expert for an e-commerce platform.

A machine learning model has suggested changing the product's pricing model to "{model_name}".

Here are the product's features:
- Price: {product.get('price')}
- Category: {product.get('category')}
- Return rate: {product.get('return_rate')}
- Repeat rate: {product.get('repeat_rate')}
- Churn rate: {product.get('churn_rate')}
- Is consumable: {product.get('is_consumable')}
- Is seasonal: {product.get('is_seasonal')}
- Shipping cost: {product.get('shipping_cost')}
- Traffic source: {product.get('traffic_source')}

Here is an example of the kind of explanation you should give:
Example:
Product features:
- Category: food
- Repeat rate: 0.1
- Churn rate: 0.5
- Is seasonal: 1
Suggested pricing model: freemium

Sample explanation:
Because of high churn rate and a seasonal food product, a freemium model offering a free sample might attract new customers and increase trial.


Now, for the product above, write a similar explanation (about 30 words) that starts with 'Because' or 'Due to', clearly explaining how the product's features make the "{model_name}" pricing model a good choice. Use simple language anyone can understand.
"""
    response = model.generate_content(prompt)
    return response.text.strip()