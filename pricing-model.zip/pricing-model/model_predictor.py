# model_predictor.py
from pydantic import BaseModel
import joblib
import pandas as pd
import os
import google.generativeai as genai

# Load model + encoders
model = joblib.load("pricing_model.pkl")
label_encoders = joblib.load("label_encoders.pkl")

# Pydantic input schema
class ProductInput(BaseModel):
    price: float
    category: str
    return_rate: float
    repeat_rate: float
    churn_rate: float
    is_consumable: int
    is_seasonal: int
    shipping_cost: float
    traffic_source: str

def label_safe(le, value):
    return value in le.classes_

def predict_strategy(data: ProductInput):
    unseen_fields = []

    # Remove any assignment or conditional loading of label_encoders/model here
    if not label_safe(label_encoders['category'], data.category):
        unseen_fields.append("category")
    if not label_safe(label_encoders['traffic_source'], data.traffic_source):
        unseen_fields.append("traffic_source")

    if unseen_fields:
        return {
            "suggested_pricing_model": "unknown",
            "message": f"Model not trained on these value(s): {', '.join(unseen_fields)}"
        }

    input_df = pd.DataFrame([{
        "price": data.price,
        "category": label_encoders["category"].transform([data.category])[0],
        "return_rate": data.return_rate,
        "repeat_rate": data.repeat_rate,
        "churn_rate": data.churn_rate,
        "is_consumable": data.is_consumable,
        "is_seasonal": data.is_seasonal,
        "shipping_cost": data.shipping_cost,
        "traffic_source": label_encoders["traffic_source"].transform([data.traffic_source])[0]
    }])
    prediction = model.predict(input_df)[0]
    predicted_label = label_encoders["best_model"].inverse_transform([prediction])[0]

    return {
        "suggested_pricing_model": predicted_label
    }
